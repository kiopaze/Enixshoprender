const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use('/frontend', express.static(path.join(__dirname, 'frontend')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'frontend', 'index.html'));
});

app.get('/api/orders', (req, res) => {
  const orders = JSON.parse(fs.readFileSync('orders.json', 'utf8'));
  res.json(orders);
});

app.post('/api/orders', (req, res) => {
  const order = req.body;
  const orders = JSON.parse(fs.readFileSync('orders.json', 'utf8'));
  orders.push(order);
  fs.writeFileSync('orders.json', JSON.stringify(orders, null, 2));
  res.json({ success: true });
});

app.listen(PORT, () => console.log('✅ EnixShop backend listening on ' + PORT));
